from django import forms
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from .models import CustomUser, DonorProfile, HospitalProfile, RecipientProfile


class LoginForm(AuthenticationForm):
    username = forms.CharField(
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Username or Email', 'id': 'id_username'})
    )
    password = forms.CharField(
        widget=forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Password', 'id': 'id_password'})
    )


class UserRegistrationForm(UserCreationForm):
    ROLE_CHOICES = [
        ('donor', 'Blood/Organ Donor'),
        ('hospital', 'Hospital / Blood Bank'),
        ('recipient', 'Patient / Recipient'),
    ]
    BLOOD_TYPE_CHOICES = [
        ('', 'Select Blood Type'),
        ('A+', 'A+'), ('A-', 'A-'),
        ('B+', 'B+'), ('B-', 'B-'),
        ('AB+', 'AB+'), ('AB-', 'AB-'),
        ('O+', 'O+'), ('O-', 'O-'),
    ]
    URGENCY_CHOICES = [
        ('low', 'Low'),
        ('medium', 'Medium'),
        ('high', 'High'),
        ('critical', 'Critical'),
    ]

    first_name = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'First Name'}))
    last_name = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Last Name'}))
    email = forms.EmailField(widget=forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'Email Address'}))
    phone = forms.CharField(required=False, widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Phone Number'}))
    role = forms.ChoiceField(choices=ROLE_CHOICES, widget=forms.Select(attrs={'class': 'form-select', 'id': 'id_role'}))
    city = forms.CharField(required=False, widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'City'}))
    state = forms.CharField(required=False, widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'State'}))
    address = forms.CharField(required=False, widget=forms.Textarea(attrs={'class': 'form-control', 'rows': 2, 'placeholder': 'Full Address'}))
    password1 = forms.CharField(widget=forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Password'}))
    password2 = forms.CharField(widget=forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Confirm Password'}))

    # Donor profile fields
    donor_blood_type = forms.ChoiceField(choices=BLOOD_TYPE_CHOICES, required=False, widget=forms.Select(attrs={'class': 'form-select'}))
    date_of_birth = forms.DateField(required=False, widget=forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}))
    weight = forms.FloatField(required=False, widget=forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Weight in kg'}))
    medical_history = forms.CharField(required=False, widget=forms.Textarea(attrs={'class': 'form-control', 'rows': 3, 'placeholder': 'Any relevant medical history...'}))
    is_organ_donor = forms.BooleanField(required=False, widget=forms.CheckboxInput(attrs={'class': 'form-check-input'}))

    # Hospital profile fields
    hospital_name = forms.CharField(required=False, widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Hospital Name'}))
    license_number = forms.CharField(required=False, widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'License Number'}))
    hospital_type = forms.CharField(required=False, widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g. Government, Private'}))
    beds = forms.IntegerField(required=False, initial=0, widget=forms.NumberInput(attrs={'class': 'form-control'}))
    established_year = forms.IntegerField(required=False, widget=forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'e.g. 1990'}))
    website = forms.URLField(required=False, widget=forms.URLInput(attrs={'class': 'form-control', 'placeholder': 'https://...'}))

    # Recipient profile fields
    recipient_blood_type = forms.ChoiceField(choices=BLOOD_TYPE_CHOICES, required=False, widget=forms.Select(attrs={'class': 'form-select'}))
    required_organ = forms.CharField(required=False, widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g. Kidney'}))
    urgency_level = forms.ChoiceField(choices=URGENCY_CHOICES, required=False, initial='medium', widget=forms.Select(attrs={'class': 'form-select'}))
    doctor_name = forms.CharField(required=False, widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Doctor Name'}))
    recipient_hospital_name = forms.CharField(required=False, widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Hospital Name'}))
    medical_condition = forms.CharField(required=False, widget=forms.Textarea(attrs={'class': 'form-control', 'rows': 3, 'placeholder': 'Medical Condition...'}))

    class Meta:
        model = CustomUser
        fields = ['username', 'first_name', 'last_name', 'email', 'phone', 'role', 'city', 'state', 'address', 'password1', 'password2']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['username'].widget.attrs.update({'class': 'form-control', 'placeholder': 'Username'})

    def clean(self):
        cleaned_data = super().clean()
        role = cleaned_data.get('role')

        if role == 'donor':
            donor_blood_type = cleaned_data.get('donor_blood_type')
            date_of_birth = cleaned_data.get('date_of_birth')
            weight = cleaned_data.get('weight')

            if not donor_blood_type:
                self.add_error('donor_blood_type', 'Blood type is required for donors.')
            if not date_of_birth:
                self.add_error('date_of_birth', 'Date of birth is required for donors.')
            if not weight:
                self.add_error('weight', 'Weight is required for donors.')

        elif role == 'hospital':
            hospital_name = cleaned_data.get('hospital_name')
            license_number = cleaned_data.get('license_number')

            if not hospital_name:
                self.add_error('hospital_name', 'Hospital name is required for hospitals.')
            if not license_number:
                self.add_error('license_number', 'License number is required for hospitals.')
            elif HospitalProfile.objects.filter(license_number=license_number).exists():
                self.add_error('license_number', 'Hospital profile with this License number already exists.')

        elif role == 'recipient':
            recipient_blood_type = cleaned_data.get('recipient_blood_type')

            if not recipient_blood_type:
                self.add_error('recipient_blood_type', 'Blood type is required for recipients.')

        return cleaned_data



class DonorProfileForm(forms.ModelForm):
    class Meta:
        model = DonorProfile
        fields = ['blood_type', 'date_of_birth', 'weight', 'medical_history', 'is_organ_donor']
        widgets = {
            'blood_type': forms.Select(attrs={'class': 'form-select'}),
            'date_of_birth': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
            'weight': forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Weight in kg'}),
            'medical_history': forms.Textarea(attrs={'class': 'form-control', 'rows': 3, 'placeholder': 'Any relevant medical history...'}),
            'is_organ_donor': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Fields are conditionally required based on role — handled in view
        for field in self.fields.values():
            field.required = False


class HospitalProfileForm(forms.ModelForm):
    class Meta:
        model = HospitalProfile
        fields = ['hospital_name', 'license_number', 'hospital_type', 'beds', 'established_year', 'website']
        widgets = {
            'hospital_name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Hospital Name'}),
            'license_number': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'License Number'}),
            'hospital_type': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g. Government, Private'}),
            'beds': forms.NumberInput(attrs={'class': 'form-control'}),
            'established_year': forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'e.g. 1990'}),
            'website': forms.URLInput(attrs={'class': 'form-control', 'placeholder': 'https://...'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            field.required = False


class RecipientProfileForm(forms.ModelForm):
    class Meta:
        model = RecipientProfile
        fields = ['blood_type', 'required_organ', 'urgency_level', 'doctor_name', 'hospital_name', 'medical_condition']
        widgets = {
            'blood_type': forms.Select(attrs={'class': 'form-select'}),
            'required_organ': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g. Kidney'}),
            'urgency_level': forms.Select(attrs={'class': 'form-select'}),
            'doctor_name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Doctor Name'}),
            'hospital_name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Hospital Name'}),
            'medical_condition': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            field.required = False


class UserProfileUpdateForm(forms.ModelForm):
    class Meta:
        model = CustomUser
        fields = ['first_name', 'last_name', 'email', 'phone', 'city', 'state', 'address', 'profile_picture']
        widgets = {
            'first_name': forms.TextInput(attrs={'class': 'form-control'}),
            'last_name': forms.TextInput(attrs={'class': 'form-control'}),
            'email': forms.EmailInput(attrs={'class': 'form-control'}),
            'phone': forms.TextInput(attrs={'class': 'form-control'}),
            'city': forms.TextInput(attrs={'class': 'form-control'}),
            'state': forms.TextInput(attrs={'class': 'form-control'}),
            'address': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
            'profile_picture': forms.FileInput(attrs={'class': 'form-control'}),
        }
