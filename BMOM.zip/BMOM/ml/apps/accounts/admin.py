from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import CustomUser, DonorProfile, HospitalProfile, RecipientProfile, Notification


@admin.register(CustomUser)
class CustomUserAdmin(UserAdmin):
    list_display = ('username', 'email', 'first_name', 'last_name', 'role', 'city', 'is_active')
    list_filter = ('role', 'is_active', 'state')
    search_fields = ('username', 'email', 'first_name', 'last_name', 'phone')
    fieldsets = UserAdmin.fieldsets + (
        ('BMOM Info', {'fields': ('role', 'phone', 'address', 'city', 'state', 'profile_picture')}),
    )


@admin.register(DonorProfile)
class DonorProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'blood_type', 'date_of_birth', 'weight', 'last_donation_date', 'is_organ_donor', 'is_eligible', 'total_donations')
    list_filter = ('blood_type', 'is_organ_donor', 'is_eligible')
    search_fields = ('user__username', 'user__first_name', 'user__last_name')


@admin.register(HospitalProfile)
class HospitalProfileAdmin(admin.ModelAdmin):
    list_display = ('hospital_name', 'user', 'license_number', 'hospital_type', 'beds', 'is_verified')
    list_filter = ('is_verified', 'hospital_type')
    search_fields = ('hospital_name', 'license_number', 'user__city')
    actions = ['verify_hospitals']

    def verify_hospitals(self, request, queryset):
        queryset.update(is_verified=True)
        self.message_user(request, f'{queryset.count()} hospitals verified.')
    verify_hospitals.short_description = 'Mark selected hospitals as verified'


@admin.register(RecipientProfile)
class RecipientProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'blood_type', 'required_organ', 'urgency_level', 'doctor_name')
    list_filter = ('blood_type', 'urgency_level')
    search_fields = ('user__username', 'user__first_name')


@admin.register(Notification)
class NotificationAdmin(admin.ModelAdmin):
    list_display = ('title', 'user', 'notification_type', 'is_read', 'created_at')
    list_filter = ('notification_type', 'is_read')
    search_fields = ('title', 'user__username')
