from django.contrib.auth.models import AbstractUser
from django.db import models


class CustomUser(AbstractUser):
    ROLE_CHOICES = [
        ('admin', 'Administrator'),
        ('donor', 'Donor'),
        ('hospital', 'Hospital'),
        ('recipient', 'Recipient'),
    ]
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default='donor')
    phone = models.CharField(max_length=15, blank=True)
    address = models.TextField(blank=True)
    city = models.CharField(max_length=100, blank=True)
    state = models.CharField(max_length=100, blank=True)
    profile_picture = models.ImageField(upload_to='profiles/', blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.username} ({self.role})"

    @property
    def is_admin(self):
        return self.role == 'admin'

    @property
    def is_donor(self):
        return self.role == 'donor'

    @property
    def is_hospital(self):
        return self.role == 'hospital'

    @property
    def is_recipient(self):
        return self.role == 'recipient'


BLOOD_TYPE_CHOICES = [
    ('A+', 'A+'), ('A-', 'A-'),
    ('B+', 'B+'), ('B-', 'B-'),
    ('AB+', 'AB+'), ('AB-', 'AB-'),
    ('O+', 'O+'), ('O-', 'O-'),
]


class DonorProfile(models.Model):
    user = models.OneToOneField(CustomUser, on_delete=models.CASCADE, related_name='donor_profile')
    blood_type = models.CharField(max_length=5, choices=BLOOD_TYPE_CHOICES)
    date_of_birth = models.DateField()
    weight = models.FloatField(help_text="Weight in kg")
    last_donation_date = models.DateField(null=True, blank=True)
    medical_history = models.TextField(blank=True)
    is_organ_donor = models.BooleanField(default=False)
    is_eligible = models.BooleanField(default=True)
    total_donations = models.IntegerField(default=0)

    def __str__(self):
        return f"{self.user.get_full_name()} - {self.blood_type}"

    @property
    def can_donate(self):
        if not self.last_donation_date:
            return True
        from datetime import date
        delta = (date.today() - self.last_donation_date).days
        return delta >= 56


class HospitalProfile(models.Model):
    user = models.OneToOneField(CustomUser, on_delete=models.CASCADE, related_name='hospital_profile')
    hospital_name = models.CharField(max_length=200)
    license_number = models.CharField(max_length=100, unique=True)
    hospital_type = models.CharField(max_length=100, blank=True)
    beds = models.IntegerField(default=0)
    established_year = models.IntegerField(null=True, blank=True)
    website = models.URLField(blank=True)
    is_verified = models.BooleanField(default=False)

    def __str__(self):
        return self.hospital_name


class RecipientProfile(models.Model):
    URGENCY_CHOICES = [
        ('low', 'Low'),
        ('medium', 'Medium'),
        ('high', 'High'),
        ('critical', 'Critical'),
    ]
    user = models.OneToOneField(CustomUser, on_delete=models.CASCADE, related_name='recipient_profile')
    blood_type = models.CharField(max_length=5, choices=BLOOD_TYPE_CHOICES)
    required_organ = models.CharField(max_length=100, blank=True)
    urgency_level = models.CharField(max_length=20, choices=URGENCY_CHOICES, default='medium')
    doctor_name = models.CharField(max_length=200, blank=True)
    hospital_name = models.CharField(max_length=200, blank=True)
    medical_condition = models.TextField(blank=True)

    def __str__(self):
        return f"{self.user.get_full_name()} - Needs {self.blood_type}"


class Notification(models.Model):
    TYPE_CHOICES = [
        ('info', 'Info'),
        ('warning', 'Warning'),
        ('success', 'Success'),
        ('danger', 'Danger'),
    ]
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='notifications')
    title = models.CharField(max_length=200)
    message = models.TextField()
    notification_type = models.CharField(max_length=20, choices=TYPE_CHOICES, default='info')
    is_read = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return self.title
