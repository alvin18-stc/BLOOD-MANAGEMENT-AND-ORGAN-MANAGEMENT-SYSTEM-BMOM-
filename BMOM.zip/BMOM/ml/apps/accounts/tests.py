from django.test import TestCase
from django.urls import reverse
from django.contrib.auth import get_user_model
from apps.accounts.models import DonorProfile, HospitalProfile, RecipientProfile

User = get_user_model()

class AccountsTestCase(TestCase):
    def setUp(self):
        self.admin_user = User.objects.create_superuser(
            username='admin_test', email='admin_test@bmom.com', password='Password@123', role='admin'
        )
        self.donor_user = User.objects.create_user(
            username='donor_test', email='donor_test@bmom.com', password='Password@123', role='donor'
        )
        self.donor_profile = DonorProfile.objects.create(
            user=self.donor_user,
            blood_type='A+',
            date_of_birth='1995-05-15',
            weight=70.0
        )
        self.hospital_user = User.objects.create_user(
            username='hosp_test', email='hosp_test@bmom.com', password='Password@123', role='hospital'
        )
        self.hospital_profile = HospitalProfile.objects.create(
            user=self.hospital_user,
            hospital_name='Test Hospital',
            license_number='LIC-TEST-001'
        )
        self.recipient_user = User.objects.create_user(
            username='rec_test', email='rec_test@bmom.com', password='Password@123', role='recipient'
        )
        self.recipient_profile = RecipientProfile.objects.create(
            user=self.recipient_user,
            blood_type='O-'
        )

    def test_user_roles(self):
        self.assertTrue(self.admin_user.is_admin)
        self.assertTrue(self.donor_user.is_donor)
        self.assertTrue(self.hospital_user.is_hospital)
        self.assertTrue(self.recipient_user.is_recipient)

    def test_landing_page(self):
        response = self.client.get(reverse('landing'))
        self.assertEqual(response.status_code, 200)

    def test_login_and_redirect(self):
        self.client.login(username='donor_test', password='Password@123')
        response = self.client.get(reverse('dashboard'))
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'accounts/dashboard_donor.html')

    def test_profile_view(self):
        self.client.login(username='donor_test', password='Password@123')
        response = self.client.get(reverse('profile'))
        self.assertEqual(response.status_code, 200)

    def test_admin_user_list(self):
        # Admin can view user list
        self.client.login(username='admin_test', password='Password@123')
        response = self.client.get(reverse('user_list'))
        self.assertEqual(response.status_code, 200)

        # Donor cannot view user list
        self.client.login(username='donor_test', password='Password@123')
        response = self.client.get(reverse('user_list'))
        self.assertEqual(response.status_code, 302) # Redirected to dashboard
