from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Count, Sum
from django.db import transaction
from .forms import LoginForm, UserRegistrationForm, DonorProfileForm, HospitalProfileForm, RecipientProfileForm, UserProfileUpdateForm
from .models import CustomUser, DonorProfile, HospitalProfile, RecipientProfile, Notification


def landing_page(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    stats = {
        'total_donors': DonorProfile.objects.count(),
        'total_hospitals': HospitalProfile.objects.count(),
        'total_users': CustomUser.objects.count(),
    }
    return render(request, 'accounts/landing.html', {'stats': stats})


def login_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    form = LoginForm(request, data=request.POST or None)
    if request.method == 'POST' and form.is_valid():
        user = form.get_user()
        login(request, user)
        messages.success(request, f'Welcome back, {user.get_full_name() or user.username}!')
        return redirect('dashboard')
    return render(request, 'accounts/login.html', {'form': form})


def register_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    form = UserRegistrationForm(request.POST or None)

    if request.method == 'POST':
        if form.is_valid():
            try:
                with transaction.atomic():
                    user = form.save()
                    role = form.cleaned_data.get('role', 'donor')

                    if role == 'donor':
                        DonorProfile.objects.create(
                            user=user,
                            blood_type=form.cleaned_data.get('donor_blood_type'),
                            date_of_birth=form.cleaned_data.get('date_of_birth'),
                            weight=form.cleaned_data.get('weight'),
                            medical_history=form.cleaned_data.get('medical_history', ''),
                            is_organ_donor=form.cleaned_data.get('is_organ_donor', False)
                        )
                    elif role == 'hospital':
                        HospitalProfile.objects.create(
                            user=user,
                            hospital_name=form.cleaned_data.get('hospital_name'),
                            license_number=form.cleaned_data.get('license_number'),
                            hospital_type=form.cleaned_data.get('hospital_type', ''),
                            beds=form.cleaned_data.get('beds', 0),
                            established_year=form.cleaned_data.get('established_year'),
                            website=form.cleaned_data.get('website', '')
                        )
                    elif role == 'recipient':
                        RecipientProfile.objects.create(
                            user=user,
                            blood_type=form.cleaned_data.get('recipient_blood_type'),
                            required_organ=form.cleaned_data.get('required_organ', ''),
                            urgency_level=form.cleaned_data.get('urgency_level', 'medium'),
                            doctor_name=form.cleaned_data.get('doctor_name', ''),
                            hospital_name=form.cleaned_data.get('recipient_hospital_name', ''),
                            medical_condition=form.cleaned_data.get('medical_condition', '')
                        )

                login(request, user)
                messages.success(request, f'Welcome to BMOM, {user.first_name or user.username}! Your account has been created.')
                return redirect('dashboard')
            except Exception as e:
                messages.error(request, f'Registration failed: {str(e)}. Please try again.')
        else:
            for field, errs in form.errors.items():
                for err in errs:
                    field_name = field.replace('_', ' ').title()
                    if field == 'password1':
                        field_name = 'Password'
                    elif field == 'password2':
                        field_name = 'Confirm Password'
                    elif field == 'donor_blood_type' or field == 'recipient_blood_type':
                        field_name = 'Blood Type'
                    elif field == 'recipient_hospital_name':
                        field_name = 'Hospital Name'
                    messages.error(request, f"{field_name}: {err}")

    return render(request, 'accounts/register.html', {
        'form': form,
    })




@login_required
def logout_view(request):
    logout(request)
    messages.info(request, 'You have been logged out.')
    return redirect('landing')


@login_required
def dashboard_view(request):
    user = request.user
    context = {'user': user}

    if user.role == 'admin' or user.is_superuser:
        from apps.blood.models import BloodInventory, BloodRequest, BloodDonation
        from apps.organs.models import OrganDonor, OrganRequest, OrganMatch
        context.update({
            'total_donors': DonorProfile.objects.count(),
            'total_hospitals': HospitalProfile.objects.count(),
            'total_recipients': RecipientProfile.objects.count(),
            'total_blood_requests': BloodRequest.objects.count(),
            'pending_requests': BloodRequest.objects.filter(status='pending').count(),
            'critical_requests': BloodRequest.objects.filter(urgency='critical').count(),
            'organ_requests': OrganRequest.objects.filter(match_status='pending').count(),
            'recent_donations': BloodDonation.objects.order_by('-created_at')[:5],
            'recent_requests': BloodRequest.objects.order_by('-request_date')[:5],
            'low_stock': BloodInventory.objects.filter(units_available__lte=5),
        })
        return render(request, 'accounts/dashboard_admin.html', context)

    elif user.role == 'donor':
        try:
            profile = user.donor_profile
            from apps.blood.models import BloodDonation, BLOOD_COMPATIBILITY
            from apps.organs.models import OrganDonor
            donor_blood = profile.blood_type
            compatible_recipients = [r for r, donors in BLOOD_COMPATIBILITY.items() if donor_blood in donors]
            context.update({
                'profile': profile,
                'donations': BloodDonation.objects.filter(donor=profile).order_by('-donation_date')[:5],
                'organ_registrations': OrganDonor.objects.filter(donor=profile),
                'total_donations': BloodDonation.objects.filter(donor=profile, status='completed').count(),
                'compatible_recipients': compatible_recipients,
            })
        except DonorProfile.DoesNotExist:
            messages.warning(request, 'Please complete your donor profile.')
        return render(request, 'accounts/dashboard_donor.html', context)

    elif user.role == 'hospital':
        try:
            profile = user.hospital_profile
            from apps.blood.models import BloodInventory, BloodRequest, BloodDonation
            context.update({
                'profile': profile,
                'inventory': BloodInventory.objects.filter(hospital=profile),
                'pending_requests': BloodRequest.objects.filter(hospital=profile, status='pending'),
                'recent_donations': BloodDonation.objects.filter(hospital=profile).order_by('-donation_date')[:5],
                'low_stock_count': BloodInventory.objects.filter(hospital=profile, units_available__lte=5).count(),
            })
        except HospitalProfile.DoesNotExist:
            messages.warning(request, 'Please complete your hospital profile.')
        return render(request, 'accounts/dashboard_hospital.html', context)

    elif user.role == 'recipient':
        try:
            profile = user.recipient_profile
            from apps.blood.models import BloodRequest
            from apps.organs.models import OrganRequest
            context.update({
                'profile': profile,
                'blood_requests': BloodRequest.objects.filter(requested_by=user).order_by('-request_date')[:5],
                'organ_requests': OrganRequest.objects.filter(recipient=profile).order_by('-request_date')[:5],
            })
        except RecipientProfile.DoesNotExist:
            messages.warning(request, 'Please complete your recipient profile.')
        return render(request, 'accounts/dashboard_recipient.html', context)

    return render(request, 'accounts/dashboard_admin.html', context)


@login_required
def profile_view(request):
    user = request.user
    user_form = UserProfileUpdateForm(request.POST or None, request.FILES or None, instance=user)
    profile_form = None

    if user.role == 'donor':
        try:
            profile_form = DonorProfileForm(request.POST or None, instance=user.donor_profile)
        except DonorProfile.DoesNotExist:
            profile_form = DonorProfileForm(request.POST or None)
    elif user.role == 'hospital':
        try:
            profile_form = HospitalProfileForm(request.POST or None, instance=user.hospital_profile)
        except HospitalProfile.DoesNotExist:
            profile_form = HospitalProfileForm(request.POST or None)
    elif user.role == 'recipient':
        try:
            profile_form = RecipientProfileForm(request.POST or None, instance=user.recipient_profile)
        except RecipientProfile.DoesNotExist:
            profile_form = RecipientProfileForm(request.POST or None)

    if request.method == 'POST':
        if user_form.is_valid():
            user_form.save()
            if profile_form and profile_form.is_valid():
                profile = profile_form.save(commit=False)
                profile.user = user
                profile.save()
            messages.success(request, 'Profile updated successfully!')
            return redirect('profile')

    return render(request, 'accounts/profile.html', {
        'user_form': user_form,
        'profile_form': profile_form,
    })


@login_required
def user_list_view(request):
    if not (request.user.role == 'admin' or request.user.is_superuser):
        messages.error(request, 'Access denied.')
        return redirect('dashboard')
    users = CustomUser.objects.all().order_by('-created_at')
    return render(request, 'accounts/user_list.html', {'users': users})
