"""Management command to seed the database with sample data for demo/testing."""
from django.core.management.base import BaseCommand
from django.contrib.auth import get_user_model
from apps.accounts.models import DonorProfile, HospitalProfile, RecipientProfile
from apps.blood.models import BloodInventory, BloodDonation, BloodRequest
from apps.organs.models import OrganDonor, OrganRequest
from datetime import date, timedelta
import random

User = get_user_model()


class Command(BaseCommand):
    help = 'Seed the database with sample data'

    def handle(self, *args, **kwargs):
        self.stdout.write('Seeding database...')
        self._create_admin()
        hospitals = self._create_hospitals()
        donors = self._create_donors()
        recipients = self._create_recipients()
        self._create_inventory(hospitals)
        self._create_donations(donors, hospitals)
        self._create_blood_requests(recipients)
        self._create_organ_donors(donors)
        self.stdout.write(self.style.SUCCESS('Database seeded successfully!'))

    def _create_admin(self):
        if not User.objects.filter(username='admin').exists():
            User.objects.create_superuser(
                username='admin', email='admin@bmom.com',
                password='Admin@1234', role='admin',
                first_name='System', last_name='Admin',
                city='New Delhi', state='Delhi'
            )
            self.stdout.write('  [+] Admin user created (admin / Admin@1234)')

    def _create_hospitals(self):
        hospital_data = [
            ('Apollo Hospital', 'LIC-001', 'Private', 500, 'Mumbai', 'Maharashtra'),
            ('AIIMS Delhi', 'LIC-002', 'Government', 1000, 'New Delhi', 'Delhi'),
            ('Fortis Healthcare', 'LIC-003', 'Private', 300, 'Bengaluru', 'Karnataka'),
            ('Lilavati Hospital', 'LIC-004', 'Private', 350, 'Mumbai', 'Maharashtra'),
        ]
        hospitals = []
        for name, lic, htype, beds, city, state in hospital_data:
            username = name.lower().replace(' ', '_')[:15]
            user, created = User.objects.get_or_create(
                username=username,
                defaults={
                    'email': f'{username}@bmom.com', 'role': 'hospital',
                    'first_name': name, 'city': city, 'state': state
                }
            )
            if created:
                user.set_password('Hospital@1234')
                user.save()
            h, _ = HospitalProfile.objects.get_or_create(
                user=user,
                defaults={'hospital_name': name, 'license_number': lic,
                          'hospital_type': htype, 'beds': beds, 'is_verified': True}
            )
            hospitals.append(h)
        self.stdout.write(f'  [+] {len(hospitals)} hospitals created')
        return hospitals

    def _create_donors(self):
        blood_types = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-']
        names = [('Rahul', 'Sharma'), ('Priya', 'Patel'), ('Amit', 'Kumar'),
                 ('Neha', 'Singh'), ('Vijay', 'Gupta'), ('Anita', 'Rao'),
                 ('Suresh', 'Nair'), ('Kavitha', 'Menon')]
        cities = ['Mumbai', 'Delhi', 'Bengaluru', 'Chennai', 'Hyderabad', 'Kolkata']
        donors = []
        for i, (fn, ln) in enumerate(names):
            username = f'donor_{fn.lower()}'
            user, created = User.objects.get_or_create(
                username=username,
                defaults={
                    'email': f'{username}@bmom.com', 'role': 'donor',
                    'first_name': fn, 'last_name': ln,
                    'city': random.choice(cities), 'state': 'India'
                }
            )
            if created:
                user.set_password('Donor@1234')
                user.save()
            d, _ = DonorProfile.objects.get_or_create(
                user=user,
                defaults={
                    'blood_type': blood_types[i % len(blood_types)],
                    'date_of_birth': date(1990, random.randint(1, 12), random.randint(1, 28)),
                    'weight': random.uniform(55, 90),
                    'last_donation_date': date.today() - timedelta(days=random.randint(60, 200)),
                    'total_donations': random.randint(1, 15),
                    'is_organ_donor': random.choice([True, False]),
                    'is_eligible': True,
                }
            )
            donors.append(d)
        self.stdout.write(f'  [+] {len(donors)} donors created')
        return donors

    def _create_recipients(self):
        blood_types = ['A+', 'B+', 'O+', 'AB+']
        names = [('Sunita', 'Joshi'), ('Mohan', 'Das'), ('Lakshmi', 'Iyer')]
        recipients = []
        for i, (fn, ln) in enumerate(names):
            username = f'recipient_{fn.lower()}'
            user, created = User.objects.get_or_create(
                username=username,
                defaults={
                    'email': f'{username}@bmom.com', 'role': 'recipient',
                    'first_name': fn, 'last_name': ln, 'city': 'Mumbai', 'state': 'Maharashtra'
                }
            )
            if created:
                user.set_password('Recipient@1234')
                user.save()
            r, _ = RecipientProfile.objects.get_or_create(
                user=user,
                defaults={
                    'blood_type': blood_types[i % len(blood_types)],
                    'urgency_level': random.choice(['medium', 'high']),
                    'doctor_name': 'Dr. Rajesh Kumar',
                    'hospital_name': 'Apollo Hospital',
                }
            )
            recipients.append(r)
        self.stdout.write(f'  [+] {len(recipients)} recipients created')
        return recipients

    def _create_inventory(self, hospitals):
        blood_types = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-']
        for hospital in hospitals:
            for bt in blood_types:
                BloodInventory.objects.get_or_create(
                    hospital=hospital, blood_type=bt,
                    expiry_date=date.today() + timedelta(days=random.randint(5, 42)),
                    defaults={'units_available': random.randint(0, 50)}
                )
        self.stdout.write('  [+] Blood inventory created')

    def _create_donations(self, donors, hospitals):
        for donor in donors[:4]:
            BloodDonation.objects.get_or_create(
                donor=donor, hospital=hospitals[0],
                blood_type=donor.blood_type,
                donation_date=date.today() - timedelta(days=random.randint(10, 100)),
                defaults={'units': 1.0, 'status': 'completed'}
            )
        self.stdout.write('  [+] Donation records created')

    def _create_blood_requests(self, recipients):
        urgencies = ['low', 'medium', 'high', 'critical']
        for r in recipients:
            user = r.user
            BloodRequest.objects.get_or_create(
                requested_by=user, blood_type=r.blood_type,
                patient_name=user.get_full_name(),
                defaults={
                    'units_needed': random.randint(1, 5),
                    'urgency': random.choice(urgencies),
                    'reason': 'Medical emergency requiring blood transfusion.',
                    'status': random.choice(['pending', 'approved']),
                }
            )
        self.stdout.write('  [+] Blood requests created')

    def _create_organ_donors(self, donors):
        organs = ['kidney', 'liver', 'cornea', 'heart', 'lung']
        for i, donor in enumerate(donors[:5]):
            if donor.is_organ_donor:
                OrganDonor.objects.get_or_create(
                    donor=donor, organ_type=organs[i % len(organs)],
                    defaults={'availability_status': 'available', 'is_living_donor': True}
                )
        self.stdout.write('  [+] Organ donor registrations created')
