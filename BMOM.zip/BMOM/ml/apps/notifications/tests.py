from django.test import TestCase
from django.urls import reverse
from django.contrib.auth import get_user_model
from apps.accounts.models import Notification

User = get_user_model()

class NotificationsModuleTestCase(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(
            username='notif_user', email='notif@bmom.com', password='Password@123', role='donor'
        )
        self.notif = Notification.objects.create(
            user=self.user,
            title='Test Alert',
            message='This is a test notification.',
            notification_type='info',
            is_read=False
        )

    def test_notification_list(self):
        self.client.login(username='notif_user', password='Password@123')
        response = self.client.get(reverse('notification_list'))
        self.assertEqual(response.status_code, 200)
        self.assertIn('notifications', response.context)
        self.assertEqual(response.context['unread_count'], 1)

    def test_mark_read(self):
        self.client.login(username='notif_user', password='Password@123')
        response = self.client.get(reverse('mark_notification_read', args=[self.notif.pk]))
        self.assertEqual(response.status_code, 302) # Redirects
        self.notif.refresh_from_db()
        self.assertTrue(self.notif.is_read)

    def test_mark_all_read(self):
        self.client.login(username='notif_user', password='Password@123')
        response = self.client.get(reverse('mark_all_notifications_read'))
        self.assertEqual(response.status_code, 302) # Redirects
        self.notif.refresh_from_db()
        self.assertTrue(self.notif.is_read)
