from django.db import models
from apps.accounts.models import CustomUser, Notification


# Notifications are stored in the accounts app's Notification model.
# This app provides views/signals only.
