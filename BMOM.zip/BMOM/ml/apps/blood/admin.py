from django.contrib import admin
from .models import BloodInventory, BloodDonation, BloodRequest


@admin.register(BloodInventory)
class BloodInventoryAdmin(admin.ModelAdmin):
    list_display = ('hospital', 'blood_type', 'units_available', 'expiry_date', 'is_critical')
    list_filter = ('blood_type', 'hospital')
    search_fields = ('hospital__hospital_name', 'blood_type')
    ordering = ('expiry_date',)

    def is_critical(self, obj):
        return obj.is_critical
    is_critical.boolean = True
    is_critical.short_description = 'Critical?'


@admin.register(BloodDonation)
class BloodDonationAdmin(admin.ModelAdmin):
    list_display = ('donor', 'blood_type', 'units', 'hospital', 'donation_date', 'status')
    list_filter = ('status', 'blood_type', 'donation_date')
    search_fields = ('donor__user__username', 'hospital__hospital_name')
    date_hierarchy = 'donation_date'


@admin.register(BloodRequest)
class BloodRequestAdmin(admin.ModelAdmin):
    list_display = ('requested_by', 'blood_type', 'units_needed', 'urgency', 'status', 'request_date')
    list_filter = ('status', 'urgency', 'blood_type')
    search_fields = ('requested_by__username', 'patient_name')
    date_hierarchy = 'request_date'
    actions = ['approve_requests', 'reject_requests']

    def approve_requests(self, request, queryset):
        queryset.update(status='approved')
        self.message_user(request, f'{queryset.count()} requests approved.')
    approve_requests.short_description = 'Approve selected requests'

    def reject_requests(self, request, queryset):
        queryset.update(status='rejected')
        self.message_user(request, f'{queryset.count()} requests rejected.')
    reject_requests.short_description = 'Reject selected requests'
