from django.db import models
from apps.accounts.models import CustomUser, DonorProfile, HospitalProfile, RecipientProfile

BLOOD_TYPE_CHOICES = [
    ('A+', 'A+'), ('A-', 'A-'),
    ('B+', 'B+'), ('B-', 'B-'),
    ('AB+', 'AB+'), ('AB-', 'AB-'),
    ('O+', 'O+'), ('O-', 'O-'),
]

BLOOD_COMPATIBILITY = {
    'A+':  ['A+', 'A-', 'O+', 'O-'],
    'A-':  ['A-', 'O-'],
    'B+':  ['B+', 'B-', 'O+', 'O-'],
    'B-':  ['B-', 'O-'],
    'AB+': ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'],
    'AB-': ['A-', 'B-', 'AB-', 'O-'],
    'O+':  ['O+', 'O-'],
    'O-':  ['O-'],
}


class BloodInventory(models.Model):
    hospital = models.ForeignKey(HospitalProfile, on_delete=models.CASCADE, related_name='inventory')
    blood_type = models.CharField(max_length=5, choices=BLOOD_TYPE_CHOICES)
    units_available = models.IntegerField(default=0)
    expiry_date = models.DateField()
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name_plural = "Blood Inventories"
        unique_together = ('hospital', 'blood_type', 'expiry_date')
        ordering = ['expiry_date']

    def __str__(self):
        return f"{self.hospital.hospital_name} - {self.blood_type}: {self.units_available} units"

    @property
    def is_critical(self):
        return self.units_available <= 5

    @property
    def is_expired(self):
        from datetime import date
        return self.expiry_date < date.today()

    @property
    def days_until_expiry(self):
        from datetime import date
        delta = (self.expiry_date - date.today()).days
        return delta


class BloodDonation(models.Model):
    STATUS_CHOICES = [
        ('scheduled', 'Scheduled'),
        ('completed', 'Completed'),
        ('cancelled', 'Cancelled'),
        ('pending', 'Pending'),
    ]
    donor = models.ForeignKey(DonorProfile, on_delete=models.CASCADE, related_name='donations')
    hospital = models.ForeignKey(HospitalProfile, on_delete=models.CASCADE, related_name='received_donations')
    blood_type = models.CharField(max_length=5, choices=BLOOD_TYPE_CHOICES)
    units = models.FloatField(default=1.0, help_text="Units in pints")
    donation_date = models.DateField()
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-donation_date']

    def __str__(self):
        return f"{self.donor} donated {self.units} units on {self.donation_date}"


class BloodRequest(models.Model):
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('fulfilled', 'Fulfilled'),
        ('rejected', 'Rejected'),
        ('cancelled', 'Cancelled'),
    ]
    URGENCY_CHOICES = [
        ('low', 'Low'),
        ('medium', 'Medium'),
        ('high', 'High'),
        ('critical', 'Critical'),
    ]
    requested_by = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='blood_requests')
    hospital = models.ForeignKey(HospitalProfile, on_delete=models.CASCADE, related_name='blood_requests', null=True, blank=True)
    blood_type = models.CharField(max_length=5, choices=BLOOD_TYPE_CHOICES)
    units_needed = models.IntegerField(default=1)
    urgency = models.CharField(max_length=20, choices=URGENCY_CHOICES, default='medium')
    patient_name = models.CharField(max_length=200)
    reason = models.TextField()
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    request_date = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    notes = models.TextField(blank=True)

    class Meta:
        ordering = ['-request_date']

    def __str__(self):
        return f"Request for {self.blood_type} by {self.requested_by.username}"
