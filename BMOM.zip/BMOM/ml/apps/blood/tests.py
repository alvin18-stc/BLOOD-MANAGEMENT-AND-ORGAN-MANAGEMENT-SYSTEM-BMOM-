from django.test import TestCase
from django.urls import reverse
from django.contrib.auth import get_user_model
from apps.accounts.models import DonorProfile, HospitalProfile
from apps.blood.models import BloodInventory, BloodDonation, BloodRequest
from datetime import date, timedelta

User = get_user_model()

class BloodModuleTestCase(TestCase):
    def setUp(self):
        self.donor_user = User.objects.create_user(
            username='donor_test', email='donor@bmom.com', password='Password@123', role='donor'
        )
        self.donor_profile = DonorProfile.objects.create(
            user=self.donor_user,
            blood_type='O+',
            date_of_birth='1990-01-01',
            weight=75.0
        )
        self.hosp_user = User.objects.create_user(
            username='hosp_test', email='hosp@bmom.com', password='Password@123', role='hospital'
        )
        self.hosp_profile = HospitalProfile.objects.create(
            user=self.hosp_user,
            hospital_name='Blood Test Hosp',
            license_number='LIC-BLOOD-01'
        )
        
    def test_blood_inventory_properties(self):
        inv = BloodInventory.objects.create(
            hospital=self.hosp_profile,
            blood_type='O+',
            units_available=4,
            expiry_date=date.today() + timedelta(days=10)
        )
        self.assertTrue(inv.is_critical)
        self.assertFalse(inv.is_expired)
        self.assertEqual(inv.days_until_expiry, 10)
        
    def test_blood_search(self):
        self.client.login(username='hosp_test', password='Password@123')
        # Search for compatible donors for O+
        response = self.client.get(reverse('blood_search'), {'blood_type': 'O+'})
        self.assertEqual(response.status_code, 200)
        self.assertIn('donors', response.context)
        self.assertEqual(len(response.context['donors']), 1)
