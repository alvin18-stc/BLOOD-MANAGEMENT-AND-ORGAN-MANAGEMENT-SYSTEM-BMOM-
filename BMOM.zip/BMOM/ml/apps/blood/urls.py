from django.urls import path
from . import views

urlpatterns = [
    path('inventory/', views.inventory_list, name='inventory_list'),
    path('inventory/add/', views.add_inventory, name='add_inventory'),
    path('donations/', views.donation_list, name='donation_list'),
    path('donations/schedule/', views.schedule_donation, name='schedule_donation'),
    path('requests/', views.blood_request_list, name='blood_request_list'),
    path('requests/create/', views.create_blood_request, name='create_blood_request'),
    path('requests/<int:pk>/status/', views.update_request_status, name='update_request_status'),
    path('search/', views.blood_search, name='blood_search'),
    path('export/csv/', views.export_inventory_csv, name='export_inventory_csv'),
]
