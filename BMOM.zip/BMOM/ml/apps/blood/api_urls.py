from django.urls import path
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from apps.blood.models import BloodInventory, BloodRequest
from apps.accounts.models import DonorProfile


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def api_inventory(request):
    inv = BloodInventory.objects.all().values('blood_type', 'units_available', 'expiry_date', 'hospital__hospital_name')
    return Response(list(inv))


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def api_blood_requests(request):
    reqs = BloodRequest.objects.filter(status='pending').values(
        'blood_type', 'units_needed', 'urgency', 'patient_name', 'status', 'request_date'
    )
    return Response(list(reqs))


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def api_donor_search(request):
    blood_type = request.query_params.get('type', '')
    from apps.blood.models import BLOOD_COMPATIBILITY
    compatible = BLOOD_COMPATIBILITY.get(blood_type, [blood_type])
    donors = DonorProfile.objects.filter(
        blood_type__in=compatible, is_eligible=True
    ).values('user__first_name', 'user__last_name', 'blood_type', 'user__city', 'total_donations')
    return Response(list(donors))


urlpatterns = [
    path('blood/inventory/', api_inventory, name='api_inventory'),
    path('blood/requests/', api_blood_requests, name='api_blood_requests'),
    path('blood/search/', api_donor_search, name='api_donor_search'),
]
