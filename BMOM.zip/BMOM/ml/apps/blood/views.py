from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Sum, Count
from django.http import JsonResponse, HttpResponse
from datetime import date, timedelta
import csv

from .models import BloodInventory, BloodDonation, BloodRequest, BLOOD_COMPATIBILITY
from .forms import BloodInventoryForm, BloodDonationForm, BloodRequestForm, BloodSearchForm
from apps.accounts.models import DonorProfile, HospitalProfile


@login_required
def inventory_list(request):
    user = request.user
    if user.role == 'hospital':
        try:
            hospital = user.hospital_profile
            inventory = BloodInventory.objects.filter(hospital=hospital)
        except HospitalProfile.DoesNotExist:
            inventory = BloodInventory.objects.none()
    else:
        inventory = BloodInventory.objects.all().select_related('hospital')

    form = BloodInventoryForm()
    return render(request, 'blood/inventory.html', {'inventory': inventory, 'form': form, 'today': date.today()})


@login_required
def add_inventory(request):
    if request.user.role not in ['hospital', 'admin']:
        messages.error(request, 'Only hospitals can manage inventory.')
        return redirect('inventory_list')
    form = BloodInventoryForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        inv = form.save(commit=False)
        if request.user.role == 'hospital':
            inv.hospital = request.user.hospital_profile
        form.save()
        messages.success(request, 'Blood inventory updated successfully!')
        # Check for low stock and alert
        if inv.units_available <= 5:
            messages.warning(request, f'⚠️ Low stock alert: Only {inv.units_available} units of {inv.blood_type} available!')
        return redirect('inventory_list')
    return render(request, 'blood/add_inventory.html', {'form': form})


@login_required
def donation_list(request):
    user = request.user
    if user.role == 'donor':
        try:
            donations = BloodDonation.objects.filter(donor=user.donor_profile)
        except DonorProfile.DoesNotExist:
            donations = BloodDonation.objects.none()
    elif user.role == 'hospital':
        try:
            donations = BloodDonation.objects.filter(hospital=user.hospital_profile)
        except HospitalProfile.DoesNotExist:
            donations = BloodDonation.objects.none()
    else:
        donations = BloodDonation.objects.all().select_related('donor__user', 'hospital')
    return render(request, 'blood/donations.html', {'donations': donations})


@login_required
def schedule_donation(request):
    if request.user.role != 'donor':
        messages.error(request, 'Only donors can schedule donations.')
        return redirect('dashboard')
    form = BloodDonationForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        donation = form.save(commit=False)
        donation.donor = request.user.donor_profile
        donation.blood_type = request.user.donor_profile.blood_type
        donation.status = 'scheduled'
        donation.save()
        # Update last donation date
        donor = request.user.donor_profile
        donor.last_donation_date = donation.donation_date
        donor.total_donations += 1
        donor.save()
        messages.success(request, '✅ Donation scheduled successfully!')
        return redirect('donation_list')
    return render(request, 'blood/schedule_donation.html', {'form': form})


@login_required
def blood_request_list(request):
    user = request.user
    if user.role == 'recipient':
        requests = BloodRequest.objects.filter(requested_by=user)
    elif user.role == 'hospital':
        try:
            requests = BloodRequest.objects.filter(hospital=user.hospital_profile)
        except HospitalProfile.DoesNotExist:
            requests = BloodRequest.objects.none()
    else:
        requests = BloodRequest.objects.all().select_related('requested_by', 'hospital')
    return render(request, 'blood/requests.html', {'requests': requests})


@login_required
def create_blood_request(request):
    form = BloodRequestForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        req = form.save(commit=False)
        req.requested_by = request.user
        req.save()
        # Create notification for hospitals
        urgency = req.urgency
        if urgency in ['high', 'critical']:
            messages.warning(request, f'🚨 Emergency blood request submitted! Urgency: {urgency.upper()}')
        else:
            messages.success(request, '✅ Blood request submitted successfully!')
        return redirect('blood_request_list')
    return render(request, 'blood/create_request.html', {'form': form})


@login_required
def update_request_status(request, pk):
    blood_request = get_object_or_404(BloodRequest, pk=pk)
    if request.user.role not in ['hospital', 'admin']:
        messages.error(request, 'Permission denied.')
        return redirect('blood_request_list')
    new_status = request.POST.get('status')
    if new_status in ['approved', 'fulfilled', 'rejected']:
        blood_request.status = new_status
        blood_request.notes = request.POST.get('notes', '')
        blood_request.save()
        messages.success(request, f'Request status updated to {new_status}.')
    return redirect('blood_request_list')


@login_required
def blood_search(request):
    form = BloodSearchForm(request.GET or None)
    donors = []
    compatible_types = []
    if request.GET and form.is_valid():
        blood_type = form.cleaned_data['blood_type']
        city = form.cleaned_data.get('city', '')
        compatible_types = BLOOD_COMPATIBILITY.get(blood_type, [blood_type])
        donors_qs = DonorProfile.objects.filter(
            blood_type__in=compatible_types,
            is_eligible=True,
        ).select_related('user')
        if city:
            donors_qs = donors_qs.filter(user__city__icontains=city)
        # AI Ranking: prioritize by can_donate and total donations
        donors = sorted(donors_qs, key=lambda d: (not d.can_donate, -d.total_donations))
    return render(request, 'blood/search.html', {
        'form': form,
        'donors': donors,
        'compatible_types': compatible_types,
    })


@login_required
def export_inventory_csv(request):
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="blood_inventory.csv"'
    writer = csv.writer(response)
    writer.writerow(['Hospital', 'Blood Type', 'Units Available', 'Expiry Date', 'Status'])
    inventory = BloodInventory.objects.all().select_related('hospital')
    for item in inventory:
        status = 'Expired' if item.is_expired else ('Critical' if item.is_critical else 'OK')
        writer.writerow([item.hospital.hospital_name, item.blood_type, item.units_available, item.expiry_date, status])
    return response
