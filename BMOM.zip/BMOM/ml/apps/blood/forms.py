from django import forms
from .models import BloodInventory, BloodDonation, BloodRequest

BLOOD_TYPE_CHOICES = [
    ('', 'Select Blood Type'),
    ('A+', 'A+'), ('A-', 'A-'),
    ('B+', 'B+'), ('B-', 'B-'),
    ('AB+', 'AB+'), ('AB-', 'AB-'),
    ('O+', 'O+'), ('O-', 'O-'),
]


class BloodInventoryForm(forms.ModelForm):
    class Meta:
        model = BloodInventory
        fields = ['blood_type', 'units_available', 'expiry_date']
        widgets = {
            'blood_type': forms.Select(attrs={'class': 'form-select'}),
            'units_available': forms.NumberInput(attrs={'class': 'form-control', 'min': 0}),
            'expiry_date': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
        }


class BloodDonationForm(forms.ModelForm):
    class Meta:
        model = BloodDonation
        fields = ['hospital', 'blood_type', 'units', 'donation_date', 'notes']
        widgets = {
            'hospital': forms.Select(attrs={'class': 'form-select'}),
            'blood_type': forms.Select(attrs={'class': 'form-select'}),
            'units': forms.NumberInput(attrs={'class': 'form-control', 'step': '0.1', 'min': '0.5'}),
            'donation_date': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
            'notes': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
        }


class BloodRequestForm(forms.ModelForm):
    class Meta:
        model = BloodRequest
        fields = ['blood_type', 'units_needed', 'urgency', 'patient_name', 'reason', 'hospital']
        widgets = {
            'blood_type': forms.Select(attrs={'class': 'form-select'}),
            'units_needed': forms.NumberInput(attrs={'class': 'form-control', 'min': 1}),
            'urgency': forms.Select(attrs={'class': 'form-select'}),
            'patient_name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Patient Full Name'}),
            'reason': forms.Textarea(attrs={'class': 'form-control', 'rows': 3, 'placeholder': 'Medical reason for blood request...'}),
            'hospital': forms.Select(attrs={'class': 'form-select'}),
        }


class BloodSearchForm(forms.Form):
    blood_type = forms.ChoiceField(
        choices=BLOOD_TYPE_CHOICES,
        widget=forms.Select(attrs={'class': 'form-select', 'id': 'blood_search_type'})
    )
    city = forms.CharField(
        required=False,
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Filter by City (optional)'})
    )
