from django.db import models
from apps.accounts.models import CustomUser


class BloodDemandForecast(models.Model):
    BLOOD_TYPE_CHOICES = [
        ('A+', 'A+'), ('A-', 'A-'),
        ('B+', 'B+'), ('B-', 'B-'),
        ('AB+', 'AB+'), ('AB-', 'AB-'),
        ('O+', 'O+'), ('O-', 'O-'),
    ]
    blood_type = models.CharField(max_length=5, choices=BLOOD_TYPE_CHOICES)
    predicted_units = models.IntegerField()
    forecast_date = models.DateField()
    confidence = models.FloatField(default=0.0, help_text="Confidence score 0-1")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['forecast_date', 'blood_type']

    def __str__(self):
        return f"Forecast {self.blood_type}: {self.predicted_units} units on {self.forecast_date}"


class SystemReport(models.Model):
    REPORT_TYPE_CHOICES = [
        ('blood_inventory', 'Blood Inventory'),
        ('donations', 'Donations'),
        ('requests', 'Requests'),
        ('organ_matches', 'Organ Matches'),
        ('forecast', 'Demand Forecast'),
        ('summary', 'Summary Report'),
    ]
    report_type = models.CharField(max_length=50, choices=REPORT_TYPE_CHOICES)
    title = models.CharField(max_length=200)
    generated_by = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, null=True)
    generated_at = models.DateTimeField(auto_now_add=True)
    file_path = models.FileField(upload_to='reports/', null=True, blank=True)
    summary_data = models.JSONField(default=dict)

    class Meta:
        ordering = ['-generated_at']

    def __str__(self):
        return f"{self.title} - {self.generated_at.strftime('%Y-%m-%d')}"
