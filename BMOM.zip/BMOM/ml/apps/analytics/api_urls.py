from django.urls import path
from apps.analytics.views import forecast_api

urlpatterns = [
    path('forecast/', forecast_api, name='api_forecast'),
]
