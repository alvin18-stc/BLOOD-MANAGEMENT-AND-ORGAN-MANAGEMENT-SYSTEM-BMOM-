from django.contrib import admin
from .models import BloodDemandForecast, SystemReport


@admin.register(BloodDemandForecast)
class BloodDemandForecastAdmin(admin.ModelAdmin):
    list_display = ('blood_type', 'predicted_units', 'forecast_date', 'confidence', 'created_at')
    list_filter = ('blood_type', 'forecast_date')
    ordering = ('forecast_date', 'blood_type')


@admin.register(SystemReport)
class SystemReportAdmin(admin.ModelAdmin):
    list_display = ('title', 'report_type', 'generated_by', 'generated_at')
    list_filter = ('report_type',)
    search_fields = ('title',)
