from django.urls import path
from . import views

urlpatterns = [
    path('', views.analytics_dashboard, name='analytics_dashboard'),
    path('export/', views.export_report_csv, name='export_report_csv'),
]
