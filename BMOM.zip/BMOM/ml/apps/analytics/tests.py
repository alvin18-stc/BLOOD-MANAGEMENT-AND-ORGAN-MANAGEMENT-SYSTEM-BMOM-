from django.test import TestCase
from django.urls import reverse
from django.contrib.auth import get_user_model
from apps.analytics.models import BloodDemandForecast
from apps.analytics.views import _get_or_generate_forecast

User = get_user_model()

class AnalyticsModuleTestCase(TestCase):
    def setUp(self):
        self.admin_user = User.objects.create_superuser(
            username='admin_test', email='admin@bmom.com', password='Password@123', role='admin'
        )
        self.donor_user = User.objects.create_user(
            username='donor_test', email='donor@bmom.com', password='Password@123', role='donor'
        )

    def test_analytics_dashboard_access(self):
        # Admin can access
        self.client.login(username='admin_test', password='Password@123')
        response = self.client.get(reverse('analytics_dashboard'))
        self.assertEqual(response.status_code, 200)

        # Donor cannot access (redirects to dashboard)
        self.client.login(username='donor_test', password='Password@123')
        response = self.client.get(reverse('analytics_dashboard'))
        self.assertEqual(response.status_code, 302)

    def test_get_or_generate_forecast(self):
        data = _get_or_generate_forecast()
        self.assertIn('labels', data)
        self.assertIn('datasets', data)
        # Should populate forecasts in DB
        forecasts = BloodDemandForecast.objects.all()
        self.assertTrue(forecasts.exists())

    def test_export_report_csv(self):
        self.client.login(username='admin_test', password='Password@123')
        response = self.client.get(reverse('export_report_csv'), {'type': 'blood'})
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response['Content-Type'], 'text/csv')
