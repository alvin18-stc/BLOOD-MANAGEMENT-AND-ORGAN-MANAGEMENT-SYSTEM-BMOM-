from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse, HttpResponse
from django.db.models import Count, Sum
from datetime import date, timedelta
import json
import csv

from apps.blood.models import BloodInventory, BloodDonation, BloodRequest
from apps.organs.models import OrganDonor, OrganRequest, OrganMatch
from apps.accounts.models import DonorProfile, HospitalProfile, RecipientProfile, CustomUser
from .models import BloodDemandForecast


@login_required
def analytics_dashboard(request):
    if request.user.role not in ['admin', 'hospital']:
        from django.shortcuts import redirect
        return redirect('dashboard')

    # Blood type distribution
    blood_dist = BloodInventory.objects.values('blood_type').annotate(total=Sum('units_available')).order_by('blood_type')
    blood_labels = [item['blood_type'] for item in blood_dist]
    blood_values = [item['total'] or 0 for item in blood_dist]

    # Monthly donations last 6 months
    months = []
    donation_counts = []
    today = date.today()
    for i in range(5, -1, -1):
        month_date = today.replace(day=1) - timedelta(days=i * 30)
        count = BloodDonation.objects.filter(
            donation_date__year=month_date.year,
            donation_date__month=month_date.month,
            status='completed'
        ).count()
        months.append(month_date.strftime('%b %Y'))
        donation_counts.append(count)

    # Request status distribution
    req_statuses = BloodRequest.objects.values('status').annotate(count=Count('id'))
    req_labels = [r['status'].title() for r in req_statuses]
    req_values = [r['count'] for r in req_statuses]

    # Organ distribution
    organ_dist = OrganDonor.objects.filter(availability_status='available').values('organ_type').annotate(count=Count('id'))
    organ_labels = [o['organ_type'].title() for o in organ_dist]
    organ_values = [o['count'] for o in organ_dist]

    # Get ML forecasts
    forecasts = BloodDemandForecast.objects.filter(forecast_date__gte=today).order_by('forecast_date', 'blood_type')
    forecast_data = _get_or_generate_forecast()

    context = {
        'blood_labels': json.dumps(blood_labels),
        'blood_values': json.dumps(blood_values),
        'month_labels': json.dumps(months),
        'donation_counts': json.dumps(donation_counts),
        'req_labels': json.dumps(req_labels),
        'req_values': json.dumps(req_values),
        'organ_labels': json.dumps(organ_labels),
        'organ_values': json.dumps(organ_values),
        'forecasts': forecasts,
        'forecast_chart_data': json.dumps(forecast_data),
        'total_units': BloodInventory.objects.aggregate(total=Sum('units_available'))['total'] or 0,
        'total_donations': BloodDonation.objects.filter(status='completed').count(),
        'total_requests': BloodRequest.objects.count(),
        'organ_matches': OrganMatch.objects.count(),
    }
    return render(request, 'analytics/dashboard.html', context)


def _get_or_generate_forecast():
    """Generate ML forecast using scikit-learn or return existing forecasts."""
    try:
        from ml.forecasting import generate_forecast
        return generate_forecast()
    except Exception:
        return _simple_forecast_fallback()


def _simple_forecast_fallback():
    """Fallback: generate simple statistical forecast from existing data."""
    blood_types = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-']
    today = date.today()
    forecast_labels = []
    forecast_datasets = {}

    for bt in blood_types:
        forecast_datasets[bt] = []

    for i in range(1, 7):
        future_date = today + timedelta(days=i * 30)
        forecast_labels.append(future_date.strftime('%b %Y'))
        for bt in blood_types:
            recent_avg = BloodRequest.objects.filter(blood_type=bt).count()
            import random
            predicted = max(1, recent_avg + random.randint(-2, 5))
            forecast_datasets[bt].append(predicted)
            BloodDemandForecast.objects.update_or_create(
                blood_type=bt, forecast_date=future_date,
                defaults={'predicted_units': predicted, 'confidence': 0.75}
            )

    return {'labels': forecast_labels, 'datasets': forecast_datasets}


@login_required
def forecast_api(request):
    data = _get_or_generate_forecast()
    return JsonResponse(data)


@login_required
def export_report_csv(request):
    report_type = request.GET.get('type', 'blood')
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = f'attachment; filename="{report_type}_report.csv"'
    writer = csv.writer(response)

    if report_type == 'blood':
        writer.writerow(['Hospital', 'Blood Type', 'Units', 'Expiry', 'Status'])
        for item in BloodInventory.objects.all().select_related('hospital'):
            status = 'Expired' if item.is_expired else ('Critical' if item.is_critical else 'Normal')
            writer.writerow([item.hospital.hospital_name, item.blood_type, item.units_available, item.expiry_date, status])
    elif report_type == 'donations':
        writer.writerow(['Donor', 'Blood Type', 'Units', 'Hospital', 'Date', 'Status'])
        for d in BloodDonation.objects.all().select_related('donor__user', 'hospital'):
            writer.writerow([d.donor.user.get_full_name(), d.blood_type, d.units, d.hospital.hospital_name, d.donation_date, d.status])
    elif report_type == 'organs':
        writer.writerow(['Donor', 'Blood Type', 'Organ', 'Status', 'Registered Date'])
        for o in OrganDonor.objects.all().select_related('donor__user'):
            writer.writerow([o.donor.user.get_full_name(), o.donor.blood_type, o.organ_type, o.availability_status, o.registered_date])

    return response
