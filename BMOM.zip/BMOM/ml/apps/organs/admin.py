from django.contrib import admin
from .models import OrganDonor, OrganRequest, OrganMatch


@admin.register(OrganDonor)
class OrganDonorAdmin(admin.ModelAdmin):
    list_display = ('donor', 'organ_type', 'availability_status', 'is_living_donor', 'registered_date')
    list_filter = ('organ_type', 'availability_status', 'is_living_donor')
    search_fields = ('donor__user__username', 'donor__user__first_name')


@admin.register(OrganRequest)
class OrganRequestAdmin(admin.ModelAdmin):
    list_display = ('recipient', 'organ_type', 'blood_type', 'urgency', 'match_status', 'request_date')
    list_filter = ('organ_type', 'urgency', 'match_status', 'blood_type')
    search_fields = ('recipient__user__username',)
    date_hierarchy = 'request_date'


@admin.register(OrganMatch)
class OrganMatchAdmin(admin.ModelAdmin):
    list_display = ('donor', 'request', 'match_score', 'status', 'matched_at')
    list_filter = ('status',)
    ordering = ('-match_score',)
