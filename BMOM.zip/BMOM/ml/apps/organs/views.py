from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Q

from .models import OrganDonor, OrganRequest, OrganMatch
from .forms import OrganDonorForm, OrganRequestForm, OrganSearchForm
from apps.accounts.models import DonorProfile, RecipientProfile

BLOOD_COMPATIBILITY = {
    'A+':  ['A+', 'A-', 'O+', 'O-'],
    'A-':  ['A-', 'O-'],
    'B+':  ['B+', 'B-', 'O+', 'O-'],
    'B-':  ['B-', 'O-'],
    'AB+': ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'],
    'AB-': ['A-', 'B-', 'AB-', 'O-'],
    'O+':  ['O+', 'O-'],
    'O-':  ['O-'],
}


@login_required
def organ_donor_list(request):
    donors = OrganDonor.objects.filter(availability_status='available').select_related('donor__user')
    return render(request, 'organs/donor_list.html', {'donors': donors})


@login_required
def register_organ_donor(request):
    if request.user.role != 'donor':
        messages.error(request, 'Only registered donors can register organs.')
        return redirect('dashboard')
    try:
        donor_profile = request.user.donor_profile
    except DonorProfile.DoesNotExist:
        messages.error(request, 'Please complete your donor profile first.')
        return redirect('profile')

    form = OrganDonorForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        organ = form.save(commit=False)
        organ.donor = donor_profile
        organ.availability_status = 'available'
        organ.save()
        # Update user as organ donor
        donor_profile.is_organ_donor = True
        donor_profile.save()
        messages.success(request, f'✅ Your {organ.organ_type} has been registered for donation.')
        return redirect('my_organ_registrations')
    return render(request, 'organs/register_organ.html', {'form': form})


@login_required
def my_organ_registrations(request):
    if request.user.role != 'donor':
        return redirect('dashboard')
    try:
        donor_profile = request.user.donor_profile
        registrations = OrganDonor.objects.filter(donor=donor_profile)
    except DonorProfile.DoesNotExist:
        registrations = []
    return render(request, 'organs/my_registrations.html', {'registrations': registrations})


@login_required
def update_organ_status(request, pk):
    organ = get_object_or_404(OrganDonor, pk=pk)
    if request.user.role == 'donor' and organ.donor != request.user.donor_profile:
        messages.error(request, 'Permission denied.')
        return redirect('my_organ_registrations')
    new_status = request.POST.get('status')
    if new_status in ['available', 'unavailable']:
        organ.availability_status = new_status
        organ.save()
        messages.success(request, f'Organ status updated to {new_status}.')
    return redirect('my_organ_registrations')


@login_required
def organ_request_list(request):
    user = request.user
    if user.role == 'recipient':
        try:
            requests = OrganRequest.objects.filter(recipient=user.recipient_profile)
        except RecipientProfile.DoesNotExist:
            requests = OrganRequest.objects.none()
    else:
        requests = OrganRequest.objects.all().select_related('recipient__user')
    return render(request, 'organs/request_list.html', {'requests': requests})


@login_required
def create_organ_request(request):
    if request.user.role != 'recipient':
        messages.error(request, 'Only recipients can make organ requests.')
        return redirect('dashboard')
    try:
        recipient_profile = request.user.recipient_profile
    except RecipientProfile.DoesNotExist:
        messages.error(request, 'Please complete your recipient profile first.')
        return redirect('profile')

    form = OrganRequestForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        req = form.save(commit=False)
        req.recipient = recipient_profile
        req.save()
        # Auto-match: find compatible donors
        matches = _find_organ_matches(req)
        if matches:
            messages.success(request, f'✅ Request submitted! {len(matches)} potential donor(s) found.')
        else:
            messages.info(request, '📋 Request submitted. We will notify you when a match is found.')
        return redirect('organ_request_list')
    return render(request, 'organs/create_request.html', {'form': form})


def _find_organ_matches(organ_request):
    compatible_blood_types = BLOOD_COMPATIBILITY.get(organ_request.blood_type, [organ_request.blood_type])
    matching_donors = OrganDonor.objects.filter(
        organ_type=organ_request.organ_type,
        availability_status='available',
        donor__blood_type__in=compatible_blood_types,
    ).select_related('donor__user')

    matches_created = []
    for donor in matching_donors:
        score = _calculate_match_score(donor, organ_request)
        match, created = OrganMatch.objects.get_or_create(
            donor=donor,
            request=organ_request,
            defaults={'match_score': score, 'status': 'proposed'}
        )
        if created:
            matches_created.append(match)
    return matches_created


def _calculate_match_score(donor, request):
    score = 50.0
    # Blood type exact match
    if donor.donor.blood_type == request.blood_type:
        score += 30.0
    # Same city bonus
    if donor.donor.user.city and request.recipient.user.city:
        if donor.donor.user.city.lower() == request.recipient.user.city.lower():
            score += 15.0
    # Urgency bonus
    urgency_bonus = {'critical': 5, 'high': 3, 'medium': 1, 'low': 0}
    score += urgency_bonus.get(request.urgency, 0)
    return min(score, 100.0)


@login_required
def organ_search(request):
    form = OrganSearchForm(request.GET or None)
    donors = []
    if request.GET and form.is_valid():
        organ_type = form.cleaned_data['organ_type']
        blood_type = form.cleaned_data.get('blood_type', '')
        qs = OrganDonor.objects.filter(
            organ_type=organ_type,
            availability_status='available'
        ).select_related('donor__user')
        if blood_type:
            compatible = BLOOD_COMPATIBILITY.get(blood_type, [blood_type])
            qs = qs.filter(donor__blood_type__in=compatible)
        donors = list(qs)
    return render(request, 'organs/search.html', {'form': form, 'donors': donors})


@login_required
def organ_match_list(request):
    if request.user.role not in ['admin', 'hospital']:
        messages.error(request, 'Access denied.')
        return redirect('dashboard')
    matches = OrganMatch.objects.all().select_related('donor__donor__user', 'request__recipient__user').order_by('-match_score')
    return render(request, 'organs/matches.html', {'matches': matches})
