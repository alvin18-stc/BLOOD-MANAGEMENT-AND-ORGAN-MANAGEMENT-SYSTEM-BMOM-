from django.urls import path
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from apps.organs.models import OrganDonor, OrganMatch


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def api_organ_donors(request):
    organ_type = request.query_params.get('organ', '')
    qs = OrganDonor.objects.filter(availability_status='available')
    if organ_type:
        qs = qs.filter(organ_type=organ_type)
    data = qs.values('organ_type', 'donor__blood_type', 'donor__user__city', 'availability_status')
    return Response(list(data))


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def api_organ_matches(request):
    matches = OrganMatch.objects.all().values(
        'donor__organ_type', 'match_score', 'status',
        'donor__donor__user__first_name', 'request__recipient__user__first_name'
    )
    return Response(list(matches))


urlpatterns = [
    path('donors/', api_organ_donors, name='api_organ_donors'),
    path('matches/', api_organ_matches, name='api_organ_matches'),
]
