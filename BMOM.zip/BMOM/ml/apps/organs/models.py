from django.db import models
from apps.accounts.models import DonorProfile, RecipientProfile

ORGAN_CHOICES = [
    ('heart', 'Heart'),
    ('kidney', 'Kidney'),
    ('liver', 'Liver'),
    ('lung', 'Lung'),
    ('cornea', 'Cornea'),
    ('pancreas', 'Pancreas'),
    ('intestine', 'Intestine'),
    ('bone_marrow', 'Bone Marrow'),
    ('skin', 'Skin'),
]

BLOOD_TYPE_CHOICES = [
    ('A+', 'A+'), ('A-', 'A-'),
    ('B+', 'B+'), ('B-', 'B-'),
    ('AB+', 'AB+'), ('AB-', 'AB-'),
    ('O+', 'O+'), ('O-', 'O-'),
]


class OrganDonor(models.Model):
    STATUS_CHOICES = [
        ('registered', 'Registered'),
        ('available', 'Available'),
        ('matched', 'Matched'),
        ('donated', 'Donated'),
        ('unavailable', 'Unavailable'),
    ]
    donor = models.ForeignKey(DonorProfile, on_delete=models.CASCADE, related_name='organ_registrations')
    organ_type = models.CharField(max_length=50, choices=ORGAN_CHOICES)
    availability_status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='registered')
    registered_date = models.DateField(auto_now_add=True)
    additional_notes = models.TextField(blank=True)
    is_living_donor = models.BooleanField(default=True)

    class Meta:
        unique_together = ('donor', 'organ_type')

    def __str__(self):
        return f"{self.donor} - {self.organ_type}"


class OrganRequest(models.Model):
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('matched', 'Matched'),
        ('confirmed', 'Confirmed'),
        ('transplanted', 'Transplanted'),
        ('cancelled', 'Cancelled'),
    ]
    URGENCY_CHOICES = [
        ('low', 'Low'),
        ('medium', 'Medium'),
        ('high', 'High'),
        ('critical', 'Critical'),
    ]
    recipient = models.ForeignKey(RecipientProfile, on_delete=models.CASCADE, related_name='organ_requests')
    organ_type = models.CharField(max_length=50, choices=ORGAN_CHOICES)
    blood_type = models.CharField(max_length=5, choices=BLOOD_TYPE_CHOICES)
    urgency = models.CharField(max_length=20, choices=URGENCY_CHOICES, default='medium')
    match_status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    request_date = models.DateTimeField(auto_now_add=True)
    notes = models.TextField(blank=True)

    class Meta:
        ordering = ['-request_date']

    def __str__(self):
        return f"{self.recipient} needs {self.organ_type}"


class OrganMatch(models.Model):
    STATUS_CHOICES = [
        ('proposed', 'Proposed'),
        ('accepted', 'Accepted'),
        ('rejected', 'Rejected'),
        ('completed', 'Completed'),
    ]
    donor = models.ForeignKey(OrganDonor, on_delete=models.CASCADE, related_name='matches')
    request = models.ForeignKey(OrganRequest, on_delete=models.CASCADE, related_name='matches')
    match_score = models.FloatField(default=0.0, help_text="Compatibility score 0-100")
    matched_at = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='proposed')
    notes = models.TextField(blank=True)

    class Meta:
        ordering = ['-match_score']

    def __str__(self):
        return f"Match: {self.donor} → {self.request} ({self.match_score:.1f}%)"
