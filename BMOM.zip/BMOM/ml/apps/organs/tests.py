from django.test import TestCase
from django.urls import reverse
from django.contrib.auth import get_user_model
from apps.accounts.models import DonorProfile, RecipientProfile
from apps.organs.models import OrganDonor, OrganRequest, OrganMatch
from apps.organs.views import _calculate_match_score

User = get_user_model()

class OrgansModuleTestCase(TestCase):
    def setUp(self):
        self.donor_user = User.objects.create_user(
            username='donor_test', email='donor@bmom.com', password='Password@123', role='donor', city='Mumbai'
        )
        self.donor_profile = DonorProfile.objects.create(
            user=self.donor_user,
            blood_type='O+',
            date_of_birth='1990-01-01',
            weight=75.0,
            is_organ_donor=True
        )
        self.organ_donor = OrganDonor.objects.create(
            donor=self.donor_profile,
            organ_type='kidney',
            availability_status='available'
        )
        
        self.rec_user = User.objects.create_user(
            username='rec_test', email='rec@bmom.com', password='Password@123', role='recipient', city='Mumbai'
        )
        self.rec_profile = RecipientProfile.objects.create(
            user=self.rec_user,
            blood_type='O+',
            required_organ='kidney',
            urgency_level='critical'
        )

    def test_calculate_match_score(self):
        req = OrganRequest.objects.create(
            recipient=self.rec_profile,
            organ_type='kidney',
            blood_type='O+',
            urgency='critical'
        )
        # Score calculation: 50 base + 30 (exact blood match) + 15 (same city) + 5 (critical urgency) = 100
        score = _calculate_match_score(self.organ_donor, req)
        self.assertEqual(score, 100.0)

    def test_auto_match_creation(self):
        # View creation triggers matching
        self.client.login(username='rec_test', password='Password@123')
        response = self.client.post(reverse('create_organ_request'), {
            'organ_type': 'kidney',
            'blood_type': 'O+',
            'urgency': 'critical',
            'notes': 'Urgent'
        })
        self.assertEqual(response.status_code, 302) # Redirects on success
        
        # Verify that match has been created in DB
        matches = OrganMatch.objects.filter(donor=self.organ_donor)
        self.assertEqual(matches.count(), 1)
        self.assertEqual(matches.first().match_score, 100.0)
