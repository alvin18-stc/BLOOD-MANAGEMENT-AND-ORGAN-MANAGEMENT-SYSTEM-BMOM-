from django.urls import path
from . import views

urlpatterns = [
    path('donors/', views.organ_donor_list, name='organ_donor_list'),
    path('donors/register/', views.register_organ_donor, name='register_organ_donor'),
    path('donors/my/', views.my_organ_registrations, name='my_organ_registrations'),
    path('donors/<int:pk>/status/', views.update_organ_status, name='update_organ_status'),
    path('requests/', views.organ_request_list, name='organ_request_list'),
    path('requests/create/', views.create_organ_request, name='create_organ_request'),
    path('search/', views.organ_search, name='organ_search'),
    path('matches/', views.organ_match_list, name='organ_match_list'),
]
