from django import forms
from .models import OrganDonor, OrganRequest

ORGAN_CHOICES = [
    ('', 'Select Organ'),
    ('heart', 'Heart'),
    ('kidney', 'Kidney'),
    ('liver', 'Liver'),
    ('lung', 'Lung'),
    ('cornea', 'Cornea'),
    ('pancreas', 'Pancreas'),
    ('intestine', 'Intestine'),
    ('bone_marrow', 'Bone Marrow'),
    ('skin', 'Skin'),
]


class OrganDonorForm(forms.ModelForm):
    class Meta:
        model = OrganDonor
        fields = ['organ_type', 'is_living_donor', 'additional_notes']
        widgets = {
            'organ_type': forms.Select(attrs={'class': 'form-select'}),
            'is_living_donor': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
            'additional_notes': forms.Textarea(attrs={'class': 'form-control', 'rows': 3, 'placeholder': 'Any additional notes or medical information...'}),
        }


class OrganRequestForm(forms.ModelForm):
    class Meta:
        model = OrganRequest
        fields = ['organ_type', 'blood_type', 'urgency', 'notes']
        widgets = {
            'organ_type': forms.Select(attrs={'class': 'form-select'}),
            'blood_type': forms.Select(attrs={'class': 'form-select'}),
            'urgency': forms.Select(attrs={'class': 'form-select'}),
            'notes': forms.Textarea(attrs={'class': 'form-control', 'rows': 3, 'placeholder': 'Medical details and any additional information...'}),
        }


class OrganSearchForm(forms.Form):
    organ_type = forms.ChoiceField(
        choices=ORGAN_CHOICES,
        widget=forms.Select(attrs={'class': 'form-select'})
    )
    blood_type = forms.ChoiceField(
        choices=[('', 'Any Blood Type'), ('A+', 'A+'), ('A-', 'A-'), ('B+', 'B+'), ('B-', 'B-'),
                 ('AB+', 'AB+'), ('AB-', 'AB-'), ('O+', 'O+'), ('O-', 'O-')],
        required=False,
        widget=forms.Select(attrs={'class': 'form-select'})
    )
