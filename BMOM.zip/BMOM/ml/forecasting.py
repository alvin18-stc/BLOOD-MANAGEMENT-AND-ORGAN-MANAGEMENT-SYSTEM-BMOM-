"""
BMOM Blood Demand Forecasting ML Module
Uses scikit-learn RandomForestRegressor to predict future blood demand
based on historical request data, seasonal trends, and blood type patterns.
"""
import os
import sys
import django
import numpy as np
import pandas as pd
from datetime import date, timedelta
from pathlib import Path

# Setup Django if running standalone
BASE_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE_DIR))
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'bmom.settings')


def get_training_data():
    """Extract historical blood request data from database."""
    try:
        from apps.blood.models import BloodRequest
        requests = BloodRequest.objects.all().values(
            'blood_type', 'units_needed', 'urgency', 'request_date', 'status'
        )
        if not requests.exists() or requests.count() < 20:
            return _generate_synthetic_data()

        df = pd.DataFrame(list(requests))
        df['request_date'] = pd.to_datetime(df['request_date'])
        df['month'] = df['request_date'].dt.month
        df['day_of_week'] = df['request_date'].dt.dayofweek
        df['year'] = df['request_date'].dt.year
        df['quarter'] = df['request_date'].dt.quarter
        return df
    except Exception:
        return _generate_synthetic_data()


def _generate_synthetic_data():
    """Generate synthetic training data for initial deployment."""
    blood_types = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-']
    # Realistic demand ratios: O+ most common, AB- rarest
    demand_weights = {
        'O+': 38, 'A+': 34, 'B+': 9, 'AB+': 3,
        'O-': 7, 'A-': 6, 'B-': 2, 'AB-': 1
    }
    records = []
    start_date = date.today() - timedelta(days=365)
    for i in range(500):
        random_day = start_date + timedelta(days=np.random.randint(0, 365))
        bt = np.random.choice(blood_types, p=[demand_weights[b]/100 for b in blood_types])
        records.append({
            'blood_type': bt,
            'units_needed': np.random.randint(1, 10),
            'month': random_day.month,
            'day_of_week': random_day.weekday(),
            'year': random_day.year,
            'quarter': (random_day.month - 1) // 3 + 1,
        })
    return pd.DataFrame(records)


def encode_blood_type(bt):
    mapping = {'O-': 0, 'O+': 1, 'A-': 2, 'A+': 3, 'B-': 4, 'B+': 5, 'AB-': 6, 'AB+': 7}
    return mapping.get(bt, 0)


def train_model(df):
    """Train RandomForestRegressor for blood demand forecasting."""
    from sklearn.ensemble import RandomForestRegressor
    from sklearn.model_selection import train_test_split
    from sklearn.preprocessing import LabelEncoder
    import joblib

    df['bt_encoded'] = df['blood_type'].apply(encode_blood_type)

    # Aggregate: units needed per blood type per month
    if 'units_needed' not in df.columns:
        df['units_needed'] = np.random.randint(1, 10, len(df))

    features = ['bt_encoded', 'month', 'quarter']
    target = 'units_needed'

    # Group by blood type + month for aggregate forecasting
    grouped = df.groupby(['blood_type', 'month', 'quarter'])['units_needed'].sum().reset_index()
    grouped['bt_encoded'] = grouped['blood_type'].apply(encode_blood_type)

    X = grouped[features]
    y = grouped['units_needed']

    if len(X) < 5:
        return None

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    model = RandomForestRegressor(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)

    score = model.score(X_test, y_test)
    print(f"Model R² Score: {score:.3f}")

    # Save model
    model_path = BASE_DIR / 'ml' / 'models' / 'blood_forecast.pkl'
    model_path.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(model, model_path)
    return model, score


def load_model():
    """Load saved model or train a new one."""
    import joblib
    model_path = BASE_DIR / 'ml' / 'models' / 'blood_forecast.pkl'
    if model_path.exists():
        return joblib.load(model_path)
    df = get_training_data()
    result = train_model(df)
    if result:
        return result[0]
    return None


def generate_forecast():
    """
    Generate 6-month blood demand forecast.
    Returns dict with labels and per-blood-type predictions.
    """
    blood_types = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-']
    today = date.today()
    labels = []
    datasets = {bt: [] for bt in blood_types}

    model = load_model()

    for i in range(1, 7):
        future = today.replace(day=1) + timedelta(days=i * 31)
        labels.append(future.strftime('%b %Y'))
        month = future.month
        quarter = (month - 1) // 3 + 1

        for bt in blood_types:
            bt_enc = encode_blood_type(bt)
            if model:
                try:
                    pred = model.predict([[bt_enc, month, quarter]])[0]
                    # Seasonal adjustment: higher demand in winter (Nov-Feb)
                    if month in [11, 12, 1, 2]:
                        pred *= 1.2
                    predicted = max(1, int(round(pred)))
                except Exception:
                    predicted = _fallback_predict(bt, month)
            else:
                predicted = _fallback_predict(bt, month)

            datasets[bt].append(predicted)

            # Save to database
            try:
                from apps.analytics.models import BloodDemandForecast
                BloodDemandForecast.objects.update_or_create(
                    blood_type=bt,
                    forecast_date=future,
                    defaults={
                        'predicted_units': predicted,
                        'confidence': 0.82 if model else 0.60
                    }
                )
            except Exception:
                pass

    return {'labels': labels, 'datasets': datasets}


def _fallback_predict(blood_type, month):
    """Simple statistical fallback prediction."""
    base = {'O+': 38, 'A+': 34, 'B+': 9, 'AB+': 3, 'O-': 7, 'A-': 6, 'B-': 2, 'AB-': 1}
    seasonal = 1.2 if month in [11, 12, 1, 2] else 1.0
    return max(1, int(base.get(blood_type, 5) * seasonal * np.random.uniform(0.8, 1.2)))


if __name__ == '__main__':
    django.setup()
    print("Training blood demand forecasting model...")
    df = get_training_data()
    result = train_model(df)
    if result:
        model, score = result
        print(f"Training complete. R² = {score:.3f}")
        forecast = generate_forecast()
        print("Forecast for next 6 months:")
        for i, label in enumerate(forecast['labels']):
            print(f"\n{label}:")
            for bt, values in forecast['datasets'].items():
                print(f"  {bt}: {values[i]} units")
