// BMOM — Main JavaScript

document.addEventListener('DOMContentLoaded', function () {
  initCounters();
  initProgressBars();
  initAlertDismiss();
  initFormRoleToggle();
  initTableSearch();
  initTooltips();
});

// ── Animated Counters ──
function initCounters() {
  document.querySelectorAll('[data-count]').forEach(el => {
    const target = parseInt(el.dataset.count, 10);
    const duration = 1200;
    const step = target / (duration / 16);
    let current = 0;
    const timer = setInterval(() => {
      current += step;
      if (current >= target) { current = target; clearInterval(timer); }
      el.textContent = Math.floor(current).toLocaleString();
    }, 16);
  });
}

// ── Progress Bar Animations ──
function initProgressBars() {
  document.querySelectorAll('[data-width]').forEach(el => {
    setTimeout(() => {
      el.style.width = el.dataset.width + '%';
    }, 200);
  });
}

// ── Auto-dismiss alerts after 5s ──
function initAlertDismiss() {
  document.querySelectorAll('.alert').forEach(alert => {
    setTimeout(() => {
      alert.style.transition = 'opacity 0.5s ease';
      alert.style.opacity = '0';
      setTimeout(() => alert.remove(), 500);
    }, 5000);
  });
}

// ── Register form role toggle ──
function initFormRoleToggle() {
  const roleSelect = document.getElementById('id_role');
  if (!roleSelect) return;
  const donorSection     = document.getElementById('donor-fields');
  const hospitalSection  = document.getElementById('hospital-fields');
  const recipientSection = document.getElementById('recipient-fields');

  function setRequired(section, enable) {
    if (!section) return;
    section.querySelectorAll('input, select, textarea').forEach(el => {
      if (enable) {
        el.disabled = false;
        const originalRequired = el.dataset.wasRequired;
        if (originalRequired === 'true') el.required = true;
      } else {
        // Remember if it was required so we can restore later
        el.dataset.wasRequired = el.required;
        el.required = false;
        el.disabled = true;
      }
    });
  }

  function toggleSections(role) {
    // Hide all sections first, removing required
    [donorSection, hospitalSection, recipientSection].forEach(s => {
      if (s) s.style.display = 'none';
      setRequired(s, false);
    });
    // Show the relevant section and re-enable required
    if (role === 'donor' && donorSection) {
      donorSection.style.display = 'block';
      setRequired(donorSection, true);
    } else if (role === 'hospital' && hospitalSection) {
      hospitalSection.style.display = 'block';
      setRequired(hospitalSection, true);
    } else if (role === 'recipient' && recipientSection) {
      recipientSection.style.display = 'block';
      setRequired(recipientSection, true);
    }
  }

  // On page load: mark all sub-form fields' required status, then toggle
  [donorSection, hospitalSection, recipientSection].forEach(s => {
    if (s) s.querySelectorAll('input, select, textarea').forEach(el => {
      el.dataset.wasRequired = el.required;
    });
  });

  toggleSections(roleSelect.value);
  roleSelect.addEventListener('change', () => toggleSections(roleSelect.value));
}

// ── Client-side table search ──
function initTableSearch() {
  document.querySelectorAll('[data-search-table]').forEach(input => {
    const tableId = input.dataset.searchTable;
    const table   = document.getElementById(tableId);
    if (!table) return;
    input.addEventListener('input', function () {
      const query = this.value.toLowerCase();
      table.querySelectorAll('tbody tr').forEach(row => {
        row.style.display = row.textContent.toLowerCase().includes(query) ? '' : 'none';
      });
    });
  });
}

// ── Bootstrap tooltips ──
function initTooltips() {
  if (typeof bootstrap !== 'undefined') {
    document.querySelectorAll('[data-bs-toggle="tooltip"]').forEach(el => {
      new bootstrap.Tooltip(el);
    });
  }
}

// ── Blood type compatibility checker ──
const COMPATIBILITY = {
  'A+':  ['A+', 'A-', 'O+', 'O-'],
  'A-':  ['A-', 'O-'],
  'B+':  ['B+', 'B-', 'O+', 'O-'],
  'B-':  ['B-', 'O-'],
  'AB+': ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'],
  'AB-': ['A-', 'B-', 'AB-', 'O-'],
  'O+':  ['O+', 'O-'],
  'O-':  ['O-'],
};

function showCompatibility(bloodType) {
  const compatible = COMPATIBILITY[bloodType] || [];
  document.querySelectorAll('.blood-type-btn').forEach(btn => {
    const bt = btn.dataset.bt;
    btn.classList.toggle('compatible', compatible.includes(bt));
    btn.classList.toggle('incompatible', !compatible.includes(bt));
  });
  const result = document.getElementById('compatibility-result');
  if (result) {
    result.innerHTML = `
      <span class="text-success fw-bold">${bloodType}</span> can receive from:
      ${compatible.map(b => `<span class="blood-chip-sm ms-1">${b}</span>`).join('')}
    `;
  }
}

// ── AJAX blood request status update ──
function updateStatus(pk, status) {
  const form = document.createElement('form');
  form.method = 'POST';
  form.action = `/blood/requests/${pk}/status/`;
  form.innerHTML = `
    <input type="hidden" name="csrfmiddlewaretoken" value="${getCookie('csrftoken')}">
    <input type="hidden" name="status" value="${status}">
  `;
  document.body.appendChild(form);
  form.submit();
}

// ── CSRF cookie helper ──
function getCookie(name) {
  let cookieValue = null;
  if (document.cookie && document.cookie !== '') {
    document.cookie.split(';').forEach(cookie => {
      cookie = cookie.trim();
      if (cookie.startsWith(name + '=')) {
        cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
      }
    });
  }
  return cookieValue;
}

// ── Notification badge fetch ──
function updateNotifBadge() {
  fetch('/notifications/')
    .then(r => r.text())
    .then(() => {})
    .catch(() => {});
}

// ── Sidebar mobile toggle ──
const menuBtn = document.getElementById('menu-toggle');
const sidebar  = document.querySelector('.sidebar');
if (menuBtn && sidebar) {
  menuBtn.addEventListener('click', () => sidebar.classList.toggle('open'));
}

// ── Chart defaults ──
if (typeof Chart !== 'undefined') {
  Chart.defaults.color = '#94a3b8';
  Chart.defaults.borderColor = 'rgba(255,255,255,0.06)';
  Chart.defaults.font.family = "'Inter', sans-serif";
  Chart.defaults.plugins.legend.labels.boxWidth = 12;
  Chart.defaults.plugins.legend.labels.padding = 16;
}
