from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('apps.accounts.urls')),
    path('blood/', include('apps.blood.urls')),
    path('organs/', include('apps.organs.urls')),
    path('analytics/', include('apps.analytics.urls')),
    path('notifications/', include('apps.notifications.urls')),
    path('api/', include('apps.blood.api_urls')),
    path('api/organs/', include('apps.organs.api_urls')),
    path('api/analytics/', include('apps.analytics.api_urls')),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
